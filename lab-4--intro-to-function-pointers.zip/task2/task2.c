#include <stdio.h>
#include <stdlib.h>

/* IMPLEMENT ME: Declare your functions here */
int add (int a, int b);
int subtract (int a, int b);
int multiply (int a, int b);
int divide (int a, int b);

int (*operations[5])(int num1, int num2) = {add, subtract, multiply, divide, NULL};

int main (void)
{
	/* IMPLEMENT ME: Insert your algorithm here */
  int num1 = 10;
  int num2 = 8;
  int choice, calculation;
  printf("Choose an operation from the following menu:\n0.Add\n1.Subtract\n3.Multiply\n3.Divide\n4.Exit the program\nPlease enter choice: ");
	scanf("%d", &choice);
  //printf("%d", choice);
  calculation = operations[choice](num1, num2);
  printf("Result: %d\n", calculation);
  return 0;
}

/* IMPLEMENT ME: Define your functions here */
int add (int a, int b) { printf ("Adding 'a' and 'b'\n"); return a + b; }
int subtract (int a, int b) { printf ("Subtracting 'b' from 'a'\n");  return a - b; }
int multiply (int a, int b) { printf ("Multiplying 'a' and 'b'\n"); return a * b; }
int divide (int a, int b) { printf ("Dividing 'a' by 'b'\n"); return a / b; }